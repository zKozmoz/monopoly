package MONOPOLY.Client.ui;

import MONOPOLY.Client.network.NetworkClient;
import MONOPOLY.Model.Board;
import MONOPOLY.Protocol.Message;
import MONOPOLY.Protocol.MessageType;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.TextArea;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.scene.control.ListView;
import javafx.scene.control.Button;

import java.util.HashMap;
import java.util.Map;

public class MainController {

    @FXML private GridPane board;
    @FXML private TextArea logArea;

    private final Map<Integer, StackPane> tileMap = new HashMap<>();
    private final Circle[] playerTokens = new Circle[4];
    private NetworkClient networkClient;
    private Board gameBoard = new Board();

    @FXML
    private ListView<String> playerListView;


    private final Map<Integer, String> playerInfoMap = new HashMap<>();

    @FXML
    private Button startButton;
    @FXML
    private Button rollDiceButton;
    private boolean isOwner = false;
    private boolean gameStarted = false;



    public void handleJoinResponse(String role) {
        if ("OWNER".equals(role)) {
            log("Oda sahibi sensin. Oyuncular hazır olduğunda başlatabilirsin.");
            Platform.runLater(() -> {
                rollDiceButton.setText("OYUNU BAŞLAT (Owner)");
                rollDiceButton.setDisable(false);
            });
        } else {
            log("Oyuna katıldın. Sahibin başlatması bekleniyor...");
            Platform.runLater(() -> rollDiceButton.setDisable(true));
        }
    }

    @FXML
    private void startGame() {
        log("Game Starting...");
        networkClient.send(new Message(MessageType.START_GAME, null));
    }

    public void onGameStarted() {
        log("Oyun başladı!");
        Platform.runLater(() -> {
            rollDiceButton.setText("Zar At");
            this.gameStarted = true;
            Platform.runLater(() -> {
                startButton.setVisible(false);
                startButton.setManaged(false);
                log("Oyun başladı! Bol şans.");
            });
        });
    }

    public void setMyTurn(boolean myTurn) {
        Platform.runLater(() -> rollDiceButton.setDisable(!myTurn));
    }

    public void updatePlayerStatus(int pIdx, String name, int money) {
        Platform.runLater(() -> {
            playerInfoMap.put(pIdx, name + ": " + money + "$");

            playerListView.getItems().clear();
            playerListView.getItems().addAll(playerInfoMap.values());
        });
    }

    @FXML
    public void initialize() {
        buildBoard();
        setupTokens();
        log("Accesso in corso...");

        this.networkClient = new NetworkClient(this);
        try {
            networkClient.connect("localhost", 12345);
            networkClient.send(new Message(MessageType.JOIN_GAME, "Player " + (int)(Math.random()*100)));
        } catch (Exception e) {
            log("Errore di connessione: " + e.getMessage());
        }
    }

    private void buildBoard() {
        for (int i = 0; i < 11; i++) {
            board.getColumnConstraints().add(new ColumnConstraints(55));
            board.getRowConstraints().add(new RowConstraints(55));
        }

        int tileIndex = 0;
        for (int i = 0; i <= 10; i++) addTile(10 - i, 10, tileIndex++);
        for (int i = 1; i <= 9; i++) addTile(0, 10 - i, tileIndex++);
        for (int i = 0; i <= 10; i++) addTile(i, 0, tileIndex++);
        for (int i = 1; i <= 9; i++) addTile(10, i, tileIndex++);
    }

    private void addTile(int col, int row, int index) {
        StackPane tile = new StackPane();
        tile.setStyle("-fx-border-color: #333; -fx-background-color: beige;");

        String name = (index < gameBoard.size()) ? gameBoard.getTile(index).getName() : String.valueOf(index);
        Text label = new Text(name + "\n(" + index + ")");
        label.setStyle("-fx-font-size: 9px; -fx-text-alignment: center;");

        tile.getChildren().add(label);
        board.add(tile, col, row);
        tileMap.put(index, tile);
    }

    private void setupTokens() {
        Color[] colors = {Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW};
        for (int i = 0; i < 4; i++) {
            Circle token = new Circle(10, colors[i]);
            token.setStroke(Color.BLACK);
            playerTokens[i] = token;
            tileMap.get(0).getChildren().add(token);
        }
    }

    @FXML
    private void rollDice() {
        log("Lancio dei dadi...");
        networkClient.send(new Message(MessageType.ROLL_DICE, null));
    }

    public void log(String msg) {
        Platform.runLater(() -> logArea.appendText(msg + "\n"));
    }

    public void updateGameState(Object payload) {
        if (payload instanceof String content) {
            try {
                // Nuovo format: "INDEX:POSITION:MONEY:OWNER_INDEX:MESSAGE"
                String[] parts = content.split(":", 5);

                if (parts.length == 5) {
                    int pIdx = Integer.parseInt(parts[0]);
                    int newPos = Integer.parseInt(parts[1]);
                    int money = Integer.parseInt(parts[2]);
                    int ownerIdx = Integer.parseInt(parts[3]);
                    String message = parts[4];

                    log(message);
                    updatePlayerStatus(pIdx, "Player " + pIdx, money);

                    Platform.runLater(() -> {
                        Circle token = playerTokens[pIdx];
                        tileMap.values().forEach(pane -> pane.getChildren().remove(token));
                        if (tileMap.containsKey(newPos)) {
                            tileMap.get(newPos).getChildren().add(token);
                        }

                        if (ownerIdx != -1) {
                            updateTileColor(newPos, ownerIdx);
                        }
                    });
                }
            } catch (Exception e) {
                log("Veri ayrıştırma hatası: " + content);
            }
        }
    }
    private void updateTileColor(int tileIndex, int ownerIdx) {
        Color[] playerColors = {Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW};
        StackPane tile = tileMap.get(tileIndex);

        String hexColor = toHexString(playerColors[ownerIdx]);
        tile.setStyle("-fx-border-color: #333; -fx-background-color: " + hexColor + "; -fx-opacity: 0.8;");
    }

    private String toHexString(Color color) {
        return String.format("#%02X%02X%02X",
                (int)(color.getRed() * 255),
                (int)(color.getGreen() * 255),
                (int)(color.getBlue() * 255));
    }
}